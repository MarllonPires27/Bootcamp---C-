import 'react-native-gesture-handler';
import Routes from './Routes';
import Context from './context';

export default function App() {
  return ( 
    <Context>
      <Routes />
    </Context>
  );
}
