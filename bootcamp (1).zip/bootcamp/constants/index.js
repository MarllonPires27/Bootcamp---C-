import { default as colors } from './colors';

export { colors };
