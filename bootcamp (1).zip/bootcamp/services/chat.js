import baseURL from './api';
import AsyncStorage from '@react-native-async-storage/async-storage';
export const getChats = () => {
  return new Promise(async (resolve, reject) => {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');

    const accessToken = await AsyncStorage.getItem('@accessToken');
    if (accessToken) {
      headers.append('Authorization', `Bearer ${accessToken}`);
    }

    fetch(`${baseURL}chat/listar`, {
      method: 'GET',
      headers,
    })
      .then((response) => response.json())
      .then(resolve)
      .catch(reject);
  });
};

export const getMessages = (id) => {
  return new Promise(async (resolve, reject) => {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');

    const accessToken = await AsyncStorage.getItem('@accessToken');
    if (accessToken) {
      headers.append('Authorization', `Bearer ${accessToken}`);
    }

    fetch(`${baseURL}chat/listarmensagem/${id}`, {
      method: 'GET',
      headers,
    })
      .then((response) => response.json())
      .then(resolve)
      .catch(reject);
  });
};
export const sendMessage = (data) => {
  return new Promise(async (resolve, reject) => {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');

    const accessToken = await AsyncStorage.getItem('@accessToken');
    if (accessToken) {
      headers.append('Authorization', `Bearer ${accessToken}`);
    }

    fetch(`${baseURL}chat/mensagem`, {
      method: 'POST',
      headers,
      body: JSON.stringify(data),
    })
      .then((response) => response.json())
      .then(resolve)
      .catch(reject);
  });
};
