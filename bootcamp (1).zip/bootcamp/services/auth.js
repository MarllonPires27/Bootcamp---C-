import baseURL from './api';

import AsyncStorage from '@react-native-async-storage/async-storage';

export const signIn = async (data) => {
  return new Promise(async (resolve, reject) => {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    fetch(`${baseURL}usuario/login`, {
      headers,
      method: 'POST',
      body: JSON.stringify(data),
    })
      .then((response) => response.json())
      .then(resolve)
      .catch(reject);
  });
};

export const signUp = async (data) => {
  return new Promise(async (resolve, reject) => {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');

    fetch(`${baseURL}usuario/salvar`, {
      method: 'POST',
      headers,
      body: JSON.stringify(data),
    })
      .then((response) => response)
      .then(resolve)
      .catch(reject);
  });
};

export const getProfile = async () => {
  return new Promise(async (resolve, reject) => {
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');

    const accessToken = await AsyncStorage.getItem('@accessToken');
    if (accessToken) {
      headers.append('Authorization', `Bearer ${accessToken}`);
    }

    fetch(`${baseURL}usuario/perfil`, {
      method: 'GET',
      headers,
    })
      .then((response) => response.json())
      .then(resolve)
      .catch(reject);
  });
};
