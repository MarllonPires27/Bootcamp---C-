const baseURL = 'http://bootcamp.devart.com.br/';

export default baseURL;
