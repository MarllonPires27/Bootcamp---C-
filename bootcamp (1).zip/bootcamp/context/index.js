import AuthProvider from './AuthContext';
export default function Context({ children }) {
  return <AuthProvider>{children}</AuthProvider>;
}
