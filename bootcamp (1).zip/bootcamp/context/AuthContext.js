import { useState, useEffect, createContext } from 'react';
import { authService } from '../services';
import { Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const AuthContext = createContext({});

const initialState = {
  user: {},
  isSignedIn: false,
};

export default function AuthProvider({ children }) {
  const [state, setState] = useState(initialState);

  const signIn = async (username, password) => {
    try {
      const { accessToken, refreshToken } = await authService.signIn({
        email: username,
        senha: password,
      });

      await AsyncStorage.multiSet([
        ['@accessToken', accessToken],
        ['@refreshToken', refreshToken],
      ]);

      const user = await authService.getProfile();
      setState({
        user,
        isSignedIn: true,
      });
    } catch (e) {
      Alert.alert('Atenção', 'Tivemos um problema');
    }
  };

  useEffect(() => {
    const bootstrapAsync = async () => {
      try {
        const accessToken = await AsyncStorage.getItem('@accessToken');
        if (accessToken) {
          const user = await authService.getProfile();
          setState({
            user,
            isSignedIn: true,
          });
        }
      } catch (e) {
        console.log(e)
      }
    };
    bootstrapAsync();
  }, []);

  return (
    <AuthContext.Provider
      value={{
        state,
        action: {
          signIn,
        },
      }}>
      {children}
    </AuthContext.Provider>
  );
}
