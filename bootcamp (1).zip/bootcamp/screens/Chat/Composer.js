import React, { useState } from 'react';
import { View, TextInput, Pressable, StyleSheet } from 'react-native';
import { colors } from '../../constants';
import { Foundation } from '@expo/vector-icons';
import { Ionicons } from '@expo/vector-icons';
import Animated, { ZoomInDown, ZoomOutDown } from 'react-native-reanimated';

export default function Composer({ sendMessage }) {
  const [texto, setTexto] = useState('');
  const [pickerVisible, setPickerVisible] = useState(false);

  function togglePicker() {
    setPickerVisible((prev) => !prev);
  }

  function sendMessageWrapper() {
    const data = {
      texto,
      filename: '',
      base64File: '',
    };
    sendMessage(data);
    setTexto('');
  }

  return (
    <React.Fragment>
      {pickerVisible && (
        <Animated.View
          entering={ZoomInDown}
          exiting={ZoomOutDown}
          style={styles.picker}
        />
      )}
      <View style={styles.container}>
        <Pressable onPress={togglePicker} style={styles.left}>
          <Foundation name="paperclip" size={24} color="black" />
        </Pressable>
        <TextInput value={texto} style={styles.input} onChangeText={setTexto} />
        <Pressable onPress={sendMessageWrapper} style={styles.right}>
          <Ionicons name="send" size={24} color="black" />
        </Pressable>
      </View>
      {pickerVisible && (
        <Pressable style={StyleSheet.absoluteFill} onPress={togglePicker} />
      )}
    </React.Fragment>
  );
}

const styles = StyleSheet.create({
  picker: {
    left: 10,
    bottom: 70,
    width: 250,
    height: 150,
    borderRadius: 20,
    position: 'absolute',
    borderBottomLeftRadius: 10,
    backgroundColor: colors.primary0,
  },
  container: {
    flexDirection: 'row',
    backgroundColor: colors.primary0,
  },
  left: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  right: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    flex: 5,
    height: 45,
    marginTop: 10,
    marginBottom: 5,
    borderRadius: 20,
    paddingHorizontal: 10,
    backgroundColor: colors.neutral500,
  },
});
