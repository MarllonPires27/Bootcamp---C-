import { View, Text, StyleSheet } from 'react-native';

import { colors } from '../../constants';

export default function Message({ message }) {
  const myMessage = message.enviada;
  const date = new Date(message.dtCadastro).toLocaleDateString('pt-br', {});

  return (
    <View
      style={[
        styles.container,
        myMessage ? styles.myMessage : styles.yourMessage,
      ]}>
      {!myMessage && (
        <Text style={styles.senderName}>{message.usuario}</Text>
      )}
      <Text style={styles.message}>{message.texto}</Text>
      <Text style={[styles.date, myMessage && styles.dateMyMessage]}>
        {date}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  senderName: {
    color: colors.neutral200,
  },
  message: {
    fontSize: 15,
    marginVertical: 5,
    color: colors.neutral0,
  },
  date: {
    fontSize: 12,
    color: colors.neutral200,
  },
  dateMyMessage: {
    alignSelf: 'flex-end',
  },
  container: { padding: 10, margin: 10, borderRadius: 20 },
  myMessage: {
    alignSelf: 'flex-end',
    backgroundColor: colors.primary700,
  },
  yourMessage: {
    alignSelf: 'flex-start',
    backgroundColor: colors.secondary700,
  },
});
