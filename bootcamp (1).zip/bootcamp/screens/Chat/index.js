import { useMemo, useState, useEffect } from 'react';
import Composer from './Composer';
import {
  View,
  FlatList,
  Platform,
  StyleSheet,
  SafeAreaView,
  StatusBar,
  KeyboardAvoidingView,
} from 'react-native';

import { chatService } from '../../services';

import { useHeaderHeight } from '@react-navigation/elements';
import { colors } from '../../constants';
import Message from './Message';

export default function Chat({ route }) {
  const myId = 123;
  const headerHeight = useHeaderHeight();
  const [messages, setMessages] = useState([]);

  function renderItem({ item }) {
    return <Message message={item} myId={myId} />;
  }

  async function sendMessage(data) {
    try {
      const {
        chat: { chatId },
      } = route.params;

      await chatService.sendMessage({
        ...data,
        idChat: chatId,
      });
    } catch (e) {
      console.log(e);
    }
  }

  useEffect(() => {
    const buscarConversas = async () => {
      try {
        const {
          chat: { chatId },
        } = route.params;

        console.log(route);

        const response = await chatService.getMessages(chatId);
        setMessages(response.reverse());
      } catch (e) {
        console.log(e);
      }
    };
    setInterval(() => {
      buscarConversas();
    }, 1000);
  }, []);

  return (
    <View style={styles.container}>
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={(StatusBar.currentHeight || 0) + headerHeight}
        style={styles.container}>
        <FlatList
          inverted
          data={messages}
          renderItem={renderItem}
          keyExtractor={(item) => item.id}
        />
        <Composer sendMessage={sendMessage} />
      </KeyboardAvoidingView>
      <SafeAreaView style={styles.safeArea} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  safeArea: {
    backgroundColor: colors.primary0,
    paddingBottom: Platform.OS === 'ios' ? 0 : 10,
  },
});

const _messages = [
  {
    name: 'John Doe',
    senderId: 123,
    date: '2023-03-20',
    senderName: 'John Doe',
    content: 'Hello, how are you?',
  },
  {
    name: 'Jane Doe',
    senderId: 456,
    date: '2023-03-21',
    senderName: 'Jane Doe',
    content: 'I am doing well, thank you.',
  },
  {
    name: 'Mike Smith',
    senderId: 789,
    date: '2023-03-22',
    senderName: 'Mike Smith',
    content: 'What is up?',
  },
  {
    name: 'Sarah Jones',
    senderId: 12,
    date: '2023-03-23',
    senderName: 'Sarah Jones',
    content: 'Nothing much, just working.',
  },
  {
    name: 'David Brown',
    senderId: 345,
    date: '2023-03-24',
    senderName: 'David Brown',
    content: 'Cool.',
  },
  {
    name: 'John Doe',
    senderId: 123,
    date: '2023-03-25',
    senderName: 'John Doe',
    content: 'How was your weekend?',
  },
  {
    name: 'Jane Doe',
    senderId: 456,
    date: '2023-03-26',
    senderName: 'Jane Doe',
    content: 'It was good, thanks.',
  },
  {
    name: 'Mike Smith',
    senderId: 789,
    date: '2023-03-27',
    senderName: 'Mike Smith',
    content: 'Same here.',
  },
  {
    name: 'Sarah Jones',
    senderId: 12,
    date: '2023-03-28',
    senderName: 'Sarah Jones',
    content: 'Cool.',
  },
  {
    name: 'David Brown',
    senderId: 345,
    date: '2023-03-29',
    senderName: 'David Brown',
    content: 'I am working on a new project.',
  },
  {
    name: 'John Doe',
    senderId: 123,
    date: '2023-03-30',
    senderName: 'John Doe',
    content: 'That sounds interesting.',
  },
  {
    name: 'Jane Doe',
    senderId: 456,
    date: '2023-03-31',
    senderName: 'Jane Doe',
    content: 'I am working on a new project too.',
  },
  {
    name: 'Mike Smith',
    senderId: 789,
    date: '2023-04-01',
    senderName: 'Mike Smith',
    content: 'Cool.',
  },
  {
    name: 'Sarah Jones',
    senderId: 12,
    date: '2023-04-02',
    senderName: 'Sarah Jones',
    content: 'I am working on a new project too.',
  },
  {
    name: 'David Brown',
    senderId: 345,
    date: '2023-04-03',
    senderName: 'David Brown',
    content: 'Cool.',
  },
  {
    name: 'John Doe',
    senderId: 123,
    date: '2023-04-04',
    senderName: 'John Doe',
    content: 'I am working on a new project too.',
  },
  {
    name: 'Jane Doe',
    senderId: 456,
    date: '2023-04-05',
    senderName: 'Jane Doe',
    content: 'Cool.',
  },
  {
    name: 'Mike Smith',
    senderId: 789,
    date: '2023-04-06',
    senderName: 'Mike Smith',
    content: 'I am working on a new project too.',
  },
  {
    name: 'Sarah Jones',
    senderId: 12,
    date: '2023-04-07',
    senderName: 'Sarah Jones',
    content: 'Cool.',
  },
  {
    name: 'David Brown',
    senderId: 345,
    date: '2023-04-08',
    senderName: 'David Brown',
    content: 'Cool.',
  },
  {
    name: 'John Doe',
    senderId: 123,
    date: '2023-04-09',
    senderName: 'John Doe',
    content: 'I am working on a new project too.',
  },
  {
    name: 'Jane Doe',
    senderId: 456,
    date: '2023-04-10',
    senderName: 'Jane Doe',
    content: 'Cool.',
  },
  {
    name: 'Mike Smith',
    senderId: 789,
    date: '2023-04-11',
    senderName: 'Mike Smith',
    content: 'I am working on a new project too.',
  },
  {
    name: 'Sarah Jones',
    senderId: 12,
    date: '2023-04-12',
    senderName: 'Sarah Jones',
    content: 'Cool.',
  },
  {
    name: 'David Brown',
    senderId: 345,
    date: '2023-04-13',
    senderName: 'David Brown',
    content: 'Cool.',
  },
  {
    name: 'John Doe',
    senderId: 123,
    date: '2023-04-14',
    senderName: 'John Doe',
    content: 'I am working on a new project too.',
  },
  {
    name: 'Jane Doe',
    senderId: 456,
    date: '2023-04-15',
    senderName: 'Jane Doe',
    content: 'Cool.',
  },
  {
    name: 'Mike Smith',
    senderId: 789,
    date: '2023-04-16',
    senderName: 'Mike Smith',
    content: 'I am working on a new project too.',
  },
  {
    name: 'Sarah Jones',
    senderId: 12,
    date: '2023-04-17',
    senderName: 'Sarah Jones',
    content: 'Cool.',
  },
  {
    name: 'David Brown',
    senderName: 'David Brown',
    senderId: 345,
    date: '2023-04-17',
    content: 'I am the best',
  },
];
