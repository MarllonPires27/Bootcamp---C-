import { useState, useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import {
  View,
  Text,
  Platform,
  Keyboard,
  Pressable,
  StatusBar,
  TextInput,
  StyleSheet,
  KeyboardAvoidingView,
} from 'react-native';

import { colors } from '../constants';

export default function SignIn({ navigation }) {
  const { action } = useContext(AuthContext);

  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');

  function signIn() {
    console.log('jopjfpsd')
    action.signIn(login, password);
  }

  function navigateToSignUp() {
    navigation.navigate('SignUp');
  }

  return (
    <Pressable onPress={Keyboard.dismiss} style={styles.container}>
      <KeyboardAvoidingView
        style={styles.container}
        keyboardVerticalOffset={(StatusBar.currentHeight || 0) + 6}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.content}>
          <View style={styles.header} />

          <View style={styles.body}>
            <View style={styles.welcome}>
              <Text style={styles.welcomeTitle}>Login</Text>
              <Text style={styles.welcomeSubtitle}>
                Digite o seu login e senha
              </Text>
            </View>
            <View>
              <TextInput
                style={styles.input}
                placeholder="Email"
                placeholderTextColor={colors.neutral600}
                onChangeText={setLogin}
              />
              <TextInput
                placeholder="Senha"
                style={styles.input}
                placeholderTextColor={colors.neutral600}
                onChangeText={setPassword}
              />
            </View>
            <Pressable onPress={signIn} style={styles.submit}>
              <Text style={styles.submitText}>Entrar</Text>
            </Pressable>
          </View>

          <View style={styles.footer}>
            <Pressable onPress={navigateToSignUp}>
              <Text>Não tem uma conta? Clique aqui.</Text>
            </Pressable>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Pressable>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.primary100,
  },
  content: {
    flex: 1,
  },
  header: { flex: 1 },
  body: { flex: 2, justifyContent: 'space-around' },
  footer: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  welcome: {
    marginVertical: 10,
    marginHorizontal: 20,
  },
  welcomeTitle: {
    fontSize: 28,
    marginBottom: 5,
    fontWeight: '700',
  },
  welcomeSubtitle: {
    fontSize: 16,
    color: colors.neutral700,
  },
  input: {
    margin: 20,
    height: 40,
    borderRadius: 20,
    paddingHorizontal: 10,
    backgroundColor: colors.primary200,
  },
  submit: {
    height: 50,
    borderRadius: 40,
    alignItems: 'center',
    marginHorizontal: 20,
    justifyContent: 'center',
    backgroundColor: colors.primary900,
  },
  submitText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.neutral300,
  },
});
