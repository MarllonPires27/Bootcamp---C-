import {
  View,
  Text,
  Image,
  Pressable,
  Dimensions,
  StyleSheet,
} from 'react-native';
import { Entypo } from '@expo/vector-icons';

import user from '../../assets/user.png';

const { width } = Dimensions.get('screen');

export default function Chat({ onPress, chat }) {
  function onPressWrapper() {
    onPress && onPress(chat);
  }

  return (
    <Pressable onPress={onPressWrapper} style={styles.container}>
      <Image source={user} style={styles.image} />
      <View style={styles.info}>
        <Text numberOfLines={1} style={styles.username}>
          {chat.nome}
        </Text>
      </View>
      <Entypo name="chevron-right" size={24} color="black" />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  container: {
    height: 60,
    paddingHorizontal: 15,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  image: {
    height: 40,
    width: 40,
  },
  info: {
    height: 50,
    justifyContent: 'center',
    width: width * 0.7,
  },
  username: {
    fontSize: 18,
  },
});
