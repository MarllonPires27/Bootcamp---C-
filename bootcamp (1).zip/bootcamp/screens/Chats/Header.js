import { useContext } from 'react';
import { AuthContext } from '../../context/AuthContext';

import { View, Text, SafeAreaView, StyleSheet } from 'react-native';

export default function Header({ loading }) {
  const {
    state: { user },
  } = useContext(AuthContext);

  console.log(user);

  return (
    <SafeAreaView>
      <View style={styles.container}>
        <Text style={styles.title}>Ola {user.nome}</Text>
        <Text style={styles.subtitle}>
          {loading ? 'Carregando...' : 'Suas mensagens estão atualizadas.'}
        </Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    marginVertical: 20,
    marginHorizontal: 10,
  },
  title: {
    marginBottom: 5,
    fontSize: 24,
    fontWeight: '700',
  },
  subtitle: {
  },
});
