import { useState, useEffect } from 'react';

import { View, FlatList, StyleSheet } from 'react-native';
import { chatService } from '../../services';
import Chat from './Chat';
import Header from './Header';

export default function Chats({ navigation }) {
  const [loading, setLoading] = useState(true);
  const [chats, setChats] = useState([]);

  function navigateToChat(chat) {
    navigation.navigate('Chat', {
      chat
    });
  }

  function renderItem({ item }) {
    return <Chat chat={item} onPress={navigateToChat} />;
  }

  useEffect(() => {
    const buscarChats = async () => {
      try {
        setLoading(true);
        const response = await chatService.getChats();
        setChats(response);
      } catch (e) {
        console.log(e);
      } finally {
        setLoading(false);
      }
    };

    buscarChats();
  }, []);

  return (
    <View style={styles.container}>
      <Header loading={loading} />
      <FlatList
        data={chats}
        renderItem={renderItem}
        keyExtractor={(item) => item.chatId}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

const mock = [
  {
    id: '0',
    nome: 'Mauricio',
  },
  {
    id: '1',
    nome: 'Mauricio',
  },
  {
    id: '2',
    nome: 'Mauricio',
  },
  {
    id: '3',
    nome: 'Mauricio',
  },
  {
    id: '4',
    nome: 'Mauricio',
  },
  {
    id: '5',
    nome: 'Mauricio',
  },
  {
    id: '6',
    nome: 'Mauricio',
  },
  {
    id: '7',
    nome: 'Mauricio',
  },
];
