import { useState, useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import {
  View,
  Text,
  Alert,
  Platform,
  Keyboard,
  Pressable,
  StatusBar,
  TextInput,
  StyleSheet,
  KeyboardAvoidingView,
} from 'react-native';

import { colors } from '../constants';
import { authService } from '../services';

export default function SignUp() {
  const { action } = useContext(AuthContext);

  const [nome, setNome] = useState('');
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');

  async function signUp() {
    try {
      await authService.signUp({
        nome: nome,
        email: login,
        senha: password,
      });
      await action.signIn(login, password);
    } catch (e) {
      console.log(e);
      Alert.alert('Atenção', 'Tivemos um problema');
    }
  }

  return (
    <Pressable onPress={Keyboard.dismiss} style={styles.container}>
      <KeyboardAvoidingView
        style={styles.container}
        keyboardVerticalOffset={(StatusBar.currentHeight || 0) + 6}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <View style={styles.content}>
          <View style={styles.header} />

          <View style={styles.body}>
            <View style={styles.welcome}>
              <Text style={styles.welcomeTitle}>Cadastro</Text>
              <Text style={styles.welcomeSubtitle}>Crie uma conta.</Text>
            </View>
            <View>
              <TextInput
                placeholder="Nome"
                style={styles.input}
                placeholderTextColor={colors.neutral600}
                onChangeText={setNome}
              />
              <TextInput
                style={styles.input}
                placeholder="Email"
                placeholderTextColor={colors.neutral600}
                onChangeText={setLogin}
              />
              <TextInput
                secureTextEntry
                placeholder="Senha"
                style={styles.input}
                onChangeText={setPassword}
                placeholderTextColor={colors.neutral600}
              />
            </View>
            <Pressable onPress={signUp} style={styles.submit}>
              <Text style={styles.submitText}>Entrar</Text>
            </Pressable>
          </View>

          <View style={styles.footer} />
        </View>
      </KeyboardAvoidingView>
    </Pressable>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.primary100,
  },
  content: {
    flex: 1,
  },
  header: { flex: 1 },
  body: { flex: 3, justifyContent: 'space-around' },
  footer: { flex: 1 },
  welcome: {
    marginVertical: 10,
    marginHorizontal: 20,
  },
  welcomeTitle: {
    fontSize: 28,
    marginBottom: 5,
    fontWeight: '700',
  },
  welcomeSubtitle: {
    fontSize: 16,
    color: colors.neutral700,
  },
  input: {
    margin: 20,
    height: 40,
    borderRadius: 20,
    paddingHorizontal: 10,
    backgroundColor: colors.primary200,
  },
  submit: {
    height: 50,
    borderRadius: 40,
    alignItems: 'center',
    marginHorizontal: 20,
    justifyContent: 'center',
    backgroundColor: colors.primary900,
  },
  submitText: {
    fontSize: 16,
    fontWeight: '700',
    color: colors.neutral300,
  },
});
