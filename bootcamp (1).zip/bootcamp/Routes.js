import { useContext } from 'react';
import { AuthContext } from './context/AuthContext';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import Chat from './screens/Chat';
import Chats from './screens/Chats';
import SignIn from './screens/SignIn';
import SignUp from './screens/SignUp';

const Stack = createStackNavigator();

export default function Routes() {
  const {
    state: { isSignedIn },
  } = useContext(AuthContext);

  return (
    <NavigationContainer>
      <Stack.Navigator>
        {!isSignedIn ? (
          <Stack.Group>
            <Stack.Screen
              name="SignIn"
              component={SignIn}
              options={{
                title: 'Entrar',
                headerShown: false,
              }}
            />
            <Stack.Screen
              name="SignUp"
              component={SignUp}
              options={{
                title: '  ',
                headerTransparent: true,
              }}
            />
          </Stack.Group>
        ) : (
          <Stack.Group>
            <Stack.Screen
              name="Chats"
              component={Chats}
              options={{
                headerShown: false,
              }}
            />
            <Stack.Screen name="Chat" component={Chat} options={{}} />
          </Stack.Group>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
